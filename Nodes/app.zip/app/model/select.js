exports.select = function(response){

	var mysql = require('mysql2');

	var con = mysql.createConnection({ // change these details to match your installation
	  host: "localhost",
	  user: "yourUser",
	  password: "yourPwd", 
	  database: "mydb",
	  port:3306
	});

	con.connect(function(err) {
	  if (err) throw err;
	  con.query("SELECT * FROM users", function (err, result, fields) { // change the query to match your needs and setup
		if (err) throw err;
		console.log("From model: " + result);
		response(result);		
		
	  });
	});
}