var express = require("express");
var http = require("http");
var app = express();

var model = require('../model/select');

app.use(express.static(__dirname + "/../view"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

var users = [
  {
    id: '0',
    username: 'Robin Wieruch'
  },
  {
    id: '1',
    username: 'Dave Davids'
  }
];

http.createServer(app).listen(8080);


var cb1 = function (req, res, next) {
	console.log('Handler 1');
	//next('route'); 	// bypass all the handlers indicated in the array and go to the next route, app.get('/users', function (req, res){
	next(); 			// call the next handler in the array, cb2	
}

var cb2 = function (req, res, next) {
	console.log('Handler 2');
	next();
}

var cb3 = function (req, res) {
	console.log('Handler 3');
	return res.send(users); 
}

app.get('/users', [cb1, cb2, cb3]); 

app.get('/users', function (req, res){
	
	res.send("You were redirected here.");	
});


app.get('/users/:userId(\\d+)', function (req, res) {
		res.json(users[req.params.userId]);  
});

app.get('/users/:userId/books', function (req, res) {
	res.send("All the books of user " + req.params.userId);
});

app.get('/users/:userId/books/:bookId', function (req, res) {
	res.send("Book " + req.params.bookId + " of user " + req.params.userId);
});

app.post('/users', function (req, res) {
	users.push(req.body);
	res.send("received");
});

app.get('/db', function (req, res) {
	model.select(function(response){			
			console.log("From server:" + JSON.stringify(response));
			res.send(response);
		});
});



